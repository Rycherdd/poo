<?php
    require_once 'exe1.php';
    $p = new Pessoa();

    $p->nome = 'Rycherd';
    $p->dt_nasc = '01/09/2001';
    $p->end = 'Rua dos pardais, 61';
    $p->tel = 994497442;
    print_r($p);


?>
